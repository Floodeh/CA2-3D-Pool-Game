﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallDestroy : MonoBehaviour {


    private int count;
    private int stripesCount;
    private int spotsCount;
    public Text spotscountText;
    public Text stripescountText;
    public Text winText, loseText;
    public GameObject player;
    public GameObject white;
    private Vector3 startPos;
    // Use this for initialization
    void Start () {
        count = 0;
        stripesCount = 0;
        spotsCount = 0;
        //SetCountText();
        //SetCountTextStripes();
        //UpdateScoreSpots();
        //UpdateScoreStripes();
        winText.text = "";
        loseText.text = "";
        startPos = player.transform.position;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    //void OnTriggerEnter(Collider other)
    //{
    //    if (other.gameObject.CompareTag("spots"))
    //    {
    //        other.gameObject.SetActive(false);
    //        //spotsCount = spotsCount + 1;
    //        AddScoreSpots(1);
    //        UpdateScoreSpots();
    //        //SetCountText();
    //    }

    //    if (other.gameObject.CompareTag("stripes"))
    //    {
    //        other.gameObject.SetActive(false);
    //        //stripesCount = stripesCount + 1;
    //        AddScoreStripes(1);
    //        UpdateScoreStripes();
    //        //SetCountTextStripes();
    //    }

    //    if (other.gameObject.CompareTag("black") && spotsCount > 7)
    //    {
    //        other.gameObject.SetActive(false);
    //        //count = count + 1;
    //        //SetCountText();
    //            winText.text = "You win!";
    //    }

    //    if (other.gameObject.CompareTag("black") && stripesCount > 7)
    //    {
    //        other.gameObject.SetActive(false);
    //        //count = count + 1;
    //        //SetCountText();
    //        winText.text = "You win!";
    //    }

    //    if (other.gameObject.CompareTag("black") && spotsCount < 7)
    //    {
    //        other.gameObject.SetActive(false);
    //        //count = count + 1;
    //        //SetCountText();
    //        winText.text = "You Lose!";
    //        Time.timeScale = 0;
    //    }

    //    if (other.gameObject.CompareTag("black") && stripesCount < 7)
    //    {
    //        other.gameObject.SetActive(false);
    //        //count = count + 1;
    //        //SetCountText();
    //        winText.text = "You Lose!";
    //        Time.timeScale = 0;
    //    }

    //    if (other.gameObject.CompareTag("Player"))
    //    {
    //        player.transform.position = startPos;
    //        //other.gameObject.SetActive(false);
    //        //count = count + 1;
    //        //SetCountText();

    //    }
    //}

    ////void SetCountText()
    ////{
    ////    spotscountText.text = "Spots count: " + spotsCount.ToString();
    ////}

    ////void SetCountTextStripes()
    ////{
    ////    stripescountText.text = "Stripes count: " + stripesCount.ToString();
    ////}

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("spots"))
        {
            other.gameObject.SetActive(false);
            Score.GetScore("spots");
        }

        if (other.gameObject.CompareTag("stripes"))
        {
            other.gameObject.SetActive(false);
            Score.GetScore("stripes");
        }
        if (other.gameObject.CompareTag("stripes"))
        {
            other.gameObject.SetActive(false);
            Score.GetScore("stripes");
        }

        if (other.gameObject.CompareTag("Player"))
        {
            player.transform.position = startPos;
            //other.gameObject.SetActive(false);
        }

        if (other.gameObject.CompareTag("black"))
        {
            if(Score.spots > 6)
            {
                other.gameObject.SetActive(false);
                Score.GetScore("spots");
                win();
            }
            else if(other.gameObject.CompareTag("black") && Score.spots < 7)
            {
                other.gameObject.SetActive(false);
                lose();
            }

            if (Score.stripes > 6)
            {
                other.gameObject.SetActive(false);
                Score.GetScore("stripes");
                win();
                
            }
            else if (other.gameObject.CompareTag("black") && Score.stripes < 7)
            {
                other.gameObject.SetActive(false);
                lose();
            }
        }
    }

    public void win()
    {
        winText.text = "You win";
        loseText.enabled = false;

    }

    public void lose()
    {
        loseText.text = "You lose";
        //winText.text = "You lose";
    }

    //public void AddScoreSpots(int newScoreValue)
    //{
    //    spotsCount += newScoreValue;
    //    UpdateScoreSpots();
    //}

    //public void AddScoreStripes(int newScoreValue)
    //{
    //    stripesCount += newScoreValue;
    //    UpdateScoreStripes();
    //}

    //void UpdateScoreStripes()
    //{
    //    stripescountText.text = "Stripes: " + stripesCount;
    //}

    //void UpdateScoreSpots()
    //{
    //    spotscountText.text = "Spots: " + spotsCount;
    //}
}
