﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cue : MonoBehaviour
{

    private Rigidbody cue;
    public float speed;
    // Use this for initialization
    void Start()
    {
        cue = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);

        Invoke("HitBall", 1f);  // Calls HitBall in 1 second.

        StartCue();

    }

    void OnMouseDrag()
    {
        float distance_to_screen = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;
        Vector3 pos_move = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, distance_to_screen));
        transform.position = new Vector3(pos_move.x, transform.position.y, pos_move.z);

        cue.AddForce(pos_move * speed);

    }

    private void HitBall()
    {
        GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, 20f), ForceMode.Impulse);

    }

    private void StartCue()
    {
        if(speed < 1)
        {
            cue.gameObject.SetActive(true);
        }
    }

}
